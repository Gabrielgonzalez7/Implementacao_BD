CREATE TRIGGER TRG_ControleAlunos
ON ALUNO
AFTER INSERT
AS
BEGIN
    DECLARE @IdadeAluno INT;

    -- Pega a idade do aluno rec�m inserido
    SELECT @IdadeAluno = YEAR(GETDATE()) - YEAR(I.Data_Nascimento)
    FROM inserted I;

    -- Verifica se o aluno tem menos de 16 anos
    IF @IdadeAluno < 16
    BEGIN
        RAISERROR('ALUNO TEM MENOS DE 16 ANOS! REVENDO PROCESSO!', 14, 1);
        ROLLBACK TRANSACTION;
    END
    ELSE
    BEGIN
        PRINT 'ALUNO INSERIDO COM SUCESSO';
    END
END;

INSERT INTO ALUNO (Nome, Numero_aluno, Tipo_aluno, Curso, Data_Nascimento)
VALUES ('Teste Menor', 20, 1, 'CC', '2012-03-15');

INSERT INTO ALUNO (Nome, Numero_aluno, Tipo_aluno, Curso, Data_Nascimento)
VALUES ('Teste Maior', 21, 2, 'ADM', '2000-05-10');

INSERT INTO ALUNO (Nome, Numero_aluno, Tipo_aluno, Curso, Data_Nascimento)
VALUES('Gabriel', 78, 2, 'CC', '1999-05-23');

SELECT * FROM ALUNO;
