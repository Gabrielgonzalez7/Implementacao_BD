CREATE TRIGGER TRG_RegistroAlteracaoAluno
ON ALUNO
AFTER INSERT, DELETE, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Registro de INSERT
    INSERT INTO LOG_ALUNO (Numero_aluno, Operacao)
    SELECT I.Numero_aluno, 'INSERT'
    FROM inserted I
    WHERE NOT EXISTS (SELECT 1 FROM deleted D WHERE D.Numero_aluno = I.Numero_aluno);

    -- Registro de UPDATE
    INSERT INTO LOG_ALUNO (Numero_aluno, Operacao)
    SELECT I.Numero_aluno, 'UPDATE'
    FROM inserted I
    INNER JOIN deleted D ON I.Numero_aluno = D.Numero_aluno;

    -- Registro de DELETE
    INSERT INTO LOG_ALUNO (Numero_aluno, Operacao)
    SELECT D.Numero_aluno, 'DELETE'
    FROM deleted D;
END;

SELECT * FROM sys.tables WHERE name = 'LOG_ALUNO';

CREATE TABLE LOG_ALUNO (
    IdLog INT IDENTITY PRIMARY KEY,
    Numero_aluno INT,
    Operacao VARCHAR(20),
    Data_Operacao DATETIME DEFAULT GETDATE()
);

INSERT INTO ALUNO (Nome, Numero_aluno, Tipo_aluno, Curso, Data_Nascimento)
VALUES ('Teste Trigger', 99, 1, 'ADM', '2003-02-10');

UPDATE ALUNO SET Curso = 'ENG' WHERE Numero_aluno = 99;

DELETE FROM ALUNO WHERE Numero_aluno = 99;

SELECT * FROM LOG_ALUNO;
