USE EMPRESA;

GO
--Inserir Funcionario
CREATE OR ALTER TRIGGER trg_InserirFuncionario
ON FUNCIONARIO
INSTEAD OF INSERT
AS  
DECLARE @nome VARCHAR(100); -- FROM INSERTED
SELECT @nome = Pnome FROM inserted;
PRINT 'N�o inseri nenhum: ' + @nome
GO

-- Desabilitar o trigger criado
ALTER TABLE FUNCIONARIO
DISABLE TRIGGER trg_InserirFuncionario; 


INSERT INTO FUNCIONARIO(Cpf,Pnome,Unome,Minicial)
VALUES('2425362','Matheus','Gonzalez','A');

--Verificar a existencia do trigger
EXEC sp_helptrigger @tabname = FUNCIONARIO;





SELECT * FROM FUNCIONARIO;