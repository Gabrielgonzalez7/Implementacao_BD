USE EMPRESA;

--Exemplo 1) Troca de nomes
GO
CREATE OR ALTER TRIGGER trg_AfterUpdatePnome
ON FUNCIONARIO
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF UPDATE(Pnome)
    BEGIN 
        DECLARE @nomeNovo VARCHAR(100);
        DECLARE @nomeAntigo VARCHAR(100);

        SELECT @nomeNovo = Pnome FROM inserted;
        SELECT @nomeAntigo = Pnome FROM deleted;

        PRINT 'Era: ' + @nomeAntigo + ' | Alterado para: ' + @nomeNovo;
    END
    ELSE
    BEGIN
        PRINT 'O primeiro nome n�o foi alterado.';
    END
END
GO

SELECT * FROM FUNCIONARIO;

UPDATE FUNCIONARIO
SET Pnome = 'Leonardo'
WHERE Cpf = '2425362'
